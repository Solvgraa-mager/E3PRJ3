#include "project.h"
#include <complex.h>
#include <stdio.h>
#include <tgmath.h>
#include <stdlib.h>
#include <time.h>
#define NO_OF_SAMPLES 512 //
#define n (NO_OF_SAMPLES / 2)

uint8 DoFFT(int8* inputArray, uint16* FFTResultPtr);