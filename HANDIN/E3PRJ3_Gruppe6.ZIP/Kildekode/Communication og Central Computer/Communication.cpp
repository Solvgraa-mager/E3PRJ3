#include "Communication.h"

Communication::Communication()
{
}


Communication::~Communication()
{
}
