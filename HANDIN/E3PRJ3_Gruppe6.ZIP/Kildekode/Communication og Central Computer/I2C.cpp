#include "I2C.h"

I2C::I2C()
{
}

int I2C::send(string msg)
{
	return 0;
}

int I2C::receive()
{
	return 0;
}

I2C::~I2C()
{
}
