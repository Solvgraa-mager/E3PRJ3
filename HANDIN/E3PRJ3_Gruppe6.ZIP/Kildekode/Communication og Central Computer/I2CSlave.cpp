#include "I2CSlave.h"

I2CSlave::I2CSlave()
{

}

int I2CSlave::sendMsg(string msg)
{
	return 0;
}

int I2CSlave::receiveMsg(char *buffer, int length)
{
	return 0;
}

I2CSlave::~I2CSlave()
{
}
