#include "I2CMaster.h"

I2CMaster::I2CMaster()
{
}

int I2CMaster::sendMsg(string msg)
{
	return 0;
}

int I2CMaster::receiveMsg(char *buffer, int length)
{
	return 0;
}

I2CMaster::~I2CMaster()
{
}
